import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Chatbot from './pages/Chatbot';
import TeachingSection from './pages/TeachingSection';

function App() {
  return (
    <Router>
      <nav className='flex justify-center space-x-6 bg-gray-100 p-4'>
        <Link to='/'>Home</Link>
        <Link to='/chatbot'>Chatbot</Link>
        <Link to='/teach'>Teaching</Link>
      </nav>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/chatbot' element={<Chatbot />} />
        <Route path='/teach' element={<TeachingSection />} />
      </Routes>
    </Router>
  );
}
export default App;
