import React from 'react';
export default function Chatbot() {
  return (
    <div className='p-10 text-center'>
      <h2 className='text-3xl font-semibold mb-2'>Virtual Mediation Assistant</h2>
      <p>Chatbot interface coming soon...</p>
    </div>
  );
}
