import React from 'react';
export default function Home() {
  return (
    <div className='flex flex-col items-center justify-center h-screen text-center'>
      <h1 className='text-4xl font-bold mb-4 text-blue-700'>Welcome to Peace Bridge</h1>
      <p className='text-lg text-gray-600'>A platform for peacebuilding and conflict resolution</p>
    </div>
  );
}
