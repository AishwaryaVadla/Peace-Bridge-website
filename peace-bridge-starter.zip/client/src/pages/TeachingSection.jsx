import React from 'react';
export default function TeachingSection() {
  return (
    <div className='p-10 text-center'>
      <h2 className='text-3xl font-semibold mb-2'>Teaching Section</h2>
      <p>Learning materials and exercises will be available here soon.</p>
    </div>
  );
}
