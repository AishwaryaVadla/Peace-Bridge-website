# Peace Bridge - Starter Project

Basic structure for React frontend and Express backend.
