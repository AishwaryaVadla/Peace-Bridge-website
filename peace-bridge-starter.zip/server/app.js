import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => res.send('Peace Bridge API is running...'));
app.get('/api/chat', (req, res) => res.send('Chatbot API coming soon'));
app.get('/api/quote', (req, res) => res.send('Quote API coming soon'));
app.get('/api/teach', (req, res) => res.send('Teaching content API coming soon'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
